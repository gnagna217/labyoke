module.exports = { 
		competitionStarts: '2014-06-12',
		competitionEnds: '2014-07-13'
	};
