/*module.exports = { 
		  database: 'vm2014', 
		  username: 'postgres', 
		  password: '',
		  host: 'localhost',
		  port: '5432',
		  dialect: 'postgres',
		  native: true,
		  protocol: 'postgres'
		};
*/
module.exports = { 
		  database: 'dc1p7cvgjjk1cc', 
		  username: 'ylwkyrhqofvgpb', 
		  password: '-LFVLLwgI1bVco5Xjz-gXNhVw3',
		  host: 'ec2-54-243-249-132.compute-1.amazonaws.com',
		  port: '5432',
		  dialect: 'postgres',
		  native: true,
		  protocol: 'postgres'
		};