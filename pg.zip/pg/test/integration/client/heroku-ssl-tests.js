var helper = require(__dirname + '/../test-helper');
var pg = helper.pg;

//var host = 'ec2-107-20-224-218.compute-1.amazonaws.com';
//var database = 'db6kfntl5qhp2';
//var user = 'kwdzdnqpdiilfs';

var host = 'ec2-54-235-246-220.compute-1.amazonaws.com';
var database = 'dcabu5aaunn4re';
var user = 'ejlmxqkccfhtrr';

var port = 5432;

var config = {
  host: host,
  port: port,
  database: database,
  user: user,
  password: 'YGr6Gjn8nsuBjgyJQ_NBxQ-JTk',
  ssl: true
};

test('connection with config ssl = true', function() {
  //connect & disconnect from heroku
  pg.connect(config, assert.calls(function(err, client, done) {
    assert.isNull(err);
    client.query('SELECT NOW() as time', assert.success(function(res) {
      assert(res.rows[0].time.getTime());
      done();
      pg.end();
    }))
  }));
});